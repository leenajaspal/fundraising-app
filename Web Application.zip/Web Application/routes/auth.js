const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');

// Register a new user
router.post('/register', (req, res) => {
    const { name, email, password, bio } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ message: 'Name, email, and password are required.' });
    }
    if (global.users.find(u => u.email === email)) {
        return res.status(400).json({ message: 'User with this email already exists.' });
    }
    const newUser = { id: global.users.length + 1, name, email, password, bio: bio || '' };
    global.users.push(newUser);
    res.status(201).json({ message: 'User registered successfully.' });
});

// Login
router.post('/login', (req, res) => {
    const { email, password } = req.body;
    const user = global.users.find(u => u.email === email && u.password === password);
    if (!user) {
        return res.status(401).json({ message: 'Invalid credentials.' });
    }
    const sessionId = uuidv4();
    global.sessions[sessionId] = user.id;
    res.json({ message: 'Logged in successfully.', sessionId });
});

// Logout
router.post('/logout', (req, res) => {
    const { sessionId } = req.body;
    if (global.sessions[sessionId]) {
        delete global.sessions[sessionId];
        res.json({ message: 'Logged out successfully.' });
    } else {
        res.status(400).json({ message: 'Invalid session.' });
    }
});

// Get user profile
router.get('/profile', (req, res) => {
    const sessionId = req.headers['x-session-id'];
    const userId = global.sessions[sessionId];
    if (!userId) {
        return res.status(401).json({ message: 'Unauthorized.' });
    }
    const user = global.users.find(u => u.id === userId);
    res.json(user);
});

// Update user profile
router.put('/profile', (req, res) => {
    const sessionId = req.headers['x-session-id'];
    const userId = global.sessions[sessionId];
    if (!userId) {
        return res.status(401).json({ message: 'Unauthorized.' });
    }
    const { name, bio } = req.body;
    const user = global.users.find(u => u.id === userId);
    if (name) user.name = name;
    if (bio) user.bio = bio;
    res.json({ message: 'Profile updated successfully.' });
});

module.exports = router;
