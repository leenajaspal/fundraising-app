const express = require('express');
const router = express.Router();

// Middleware to check for authenticated user
const isAuthenticated = (req, res, next) => {
    const sessionId = req.headers['x-session-id'];
    const userId = global.sessions[sessionId];
    if (!userId) {
        return res.status(401).json({ message: 'Unauthorized.' });
    }
    req.userId = userId;
    next();
};

// Create a new fundraiser
router.post('/', isAuthenticated, (req, res) => {
    const { title, charityId, goal, description } = req.body;
    if (!title || !charityId || !goal) {
        return res.status(400).json({ message: 'Title, charity, and goal are required.' });
    }
    const charity = global.charities.find(c => c.id === charityId);
    if (!charity) {
        return res.status(400).json({ message: 'Invalid charity selected.' });
    }
    const newFundraiser = {
        id: global.fundraisers.length + 1,
        title,
        charityId,
        goal,
        description: description || '',
        amountRaised: 0,
        ownerId: req.userId,
        active: true
    };
    global.fundraisers.push(newFundraiser);
    res.status(201).json(newFundraiser);
});

// Get all active fundraisers
router.get('/', (req, res) => {
    const activeFundraisers = global.fundraisers
        .filter(f => f.active)
        .map(f => {
            const charity = global.charities.find(c => c.id === f.charityId);
            return { ...f, charityName: charity ? charity.name : 'Unknown Charity' };
        });
    res.json(activeFundraisers);
});

// Get a specific fundraiser
router.get('/:id', (req, res) => {
    const fundraiser = global.fundraisers.find(f => f.id === parseInt(req.params.id));
    if (!fundraiser) {
        return res.status(404).json({ message: 'Fundraiser not found.' });
    }
    const charity = global.charities.find(c => c.id === fundraiser.charityId);
    const owner = global.users.find(u => u.id === fundraiser.ownerId);
    const fundraiserWithDetails = {
        ...fundraiser,
        charityName: charity ? charity.name : 'Unknown Charity',
        ownerName: owner ? owner.name : 'Unknown User'
    };
    res.json(fundraiserWithDetails);
});

// Edit a fundraiser
router.put('/:id', isAuthenticated, (req, res) => {
    const fundraiser = global.fundraisers.find(f => f.id === parseInt(req.params.id));
    if (!fundraiser) {
        return res.status(404).json({ message: 'Fundraiser not found.' });
    }
    if (fundraiser.ownerId !== req.userId) {
        return res.status(403).json({ message: 'You are not the owner of this fundraiser.' });
    }
    const { title, description } = req.body;
    if (title) fundraiser.title = title;
    if (description) fundraiser.description = description;
    res.json({ message: 'Fundraiser updated successfully.' });
});

// Close a fundraiser
router.post('/:id/close', isAuthenticated, (req, res) => {
    const fundraiser = global.fundraisers.find(f => f.id === parseInt(req.params.id));
    if (!fundraiser) {
        return res.status(404).json({ message: 'Fundraiser not found.' });
    }
    if (fundraiser.ownerId !== req.userId) {
        return res.status(403).json({ message: 'You are not the owner of this fundraiser.' });
    }
    fundraiser.active = false;
    res.json({ message: 'Fundraiser closed successfully.' });
});

// Report a fundraiser
router.post('/:id/report', isAuthenticated, (req, res) => {
    const fundraiser = global.fundraisers.find(f => f.id === parseInt(req.params.id));
    if (!fundraiser) {
        return res.status(404).json({ message: 'Fundraiser not found.' });
    }
    const newReport = {
        fundraiserId: fundraiser.id,
        reporterId: req.userId,
        createdAt: new Date()
    };
    global.reports.push(newReport);
    res.status(201).json({ message: 'Fundraiser reported successfully.' });
});

module.exports = router;
