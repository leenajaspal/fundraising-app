const express = require('express');
const router = express.Router();

// Middleware to check for admin user
const isAdmin = (req, res, next) => {
    const sessionId = req.headers['x-session-id'];
    const userId = global.sessions[sessionId];
    // For simplicity, the first registered user is the admin
    if (!userId || userId !== 1) {
        return res.status(403).json({ message: 'Forbidden. Admins only.' });
    }
    req.userId = userId;
    next();
};

// --- Charity Management ---

// Get all charities
router.get('/charities', (req, res) => {
    res.json(global.charities);
});

// Add a charity
router.post('/charities', isAdmin, (req, res) => {
    const { name } = req.body;
    if (!name) {
        return res.status(400).json({ message: 'Charity name is required.' });
    }
    const newCharity = { id: global.charities.length + 1, name };
    global.charities.push(newCharity);
    res.status(201).json(newCharity);
});

// Edit a charity
router.put('/charities/:id', isAdmin, (req, res) => {
    const charity = global.charities.find(c => c.id === parseInt(req.params.id));
    if (!charity) {
        return res.status(404).json({ message: 'Charity not found.' });
    }
    const { name } = req.body;
    if (name) charity.name = name;
    res.json({ message: 'Charity updated successfully.' });
});

// Remove a charity
router.delete('/charities/:id', isAdmin, (req, res) => {
    const charityIndex = global.charities.findIndex(c => c.id === parseInt(req.params.id));
    if (charityIndex === -1) {
        return res.status(404).json({ message: 'Charity not found.' });
    }
    global.charities.splice(charityIndex, 1);
    res.json({ message: 'Charity removed successfully.' });
});


// --- Reported Fundraisers ---

// Get all reported fundraisers
router.get('/reports', isAdmin, (req, res) => {
    res.json(global.reports);
});

// Remove a fundraiser
router.delete('/fundraisers/:id', isAdmin, (req, res) => {
    const fundraiserIndex = global.fundraisers.findIndex(f => f.id === parseInt(req.params.id));
    if (fundraiserIndex === -1) {
        return res.status(404).json({ message: 'Fundraiser not found.' });
    }
    global.fundraisers.splice(fundraiserIndex, 1);
    res.json({ message: 'Fundraiser removed successfully.' });
});


module.exports = router;
