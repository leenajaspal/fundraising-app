const express = require('express');
const router = express.Router();
const paymentService = require('../services/paymentService');
const emailService = require('../services/emailService');

// Middleware to check for authenticated user
const isAuthenticated = (req, res, next) => {
    const sessionId = req.headers['x-session-id'];
    const userId = global.sessions[sessionId];
    if (!userId) {
        return res.status(401).json({ message: 'Unauthorized.' });
    }
    req.userId = userId;
    next();
};

// Make a donation to a fundraiser
router.post('/', isAuthenticated, (req, res) => {
    const { fundraiserId, amount, message, anonymous } = req.body;
    if (!fundraiserId || !amount) {
        return res.status(400).json({ message: 'Fundraiser ID and amount are required.' });
    }

    const fundraiser = global.fundraisers.find(f => f.id === fundraiserId);
    if (!fundraiser || !fundraiser.active) {
        return res.status(404).json({ message: 'Active fundraiser not found.' });
    }

    // Process payment
    const paymentSuccess = paymentService.processPayment(req.userId, amount);
    if (!paymentSuccess) {
        return res.status(500).json({ message: 'Payment processing failed.' });
    }

    const newDonation = {
        id: global.donations.length + 1,
        fundraiserId,
        donorId: anonymous ? null : req.userId,
        amount,
        message: message || '',
        createdAt: new Date()
    };
    global.donations.push(newDonation);

    // Update fundraiser progress
    fundraiser.amountRaised += amount;

    // Send email notifications
    const donor = global.users.find(u => u.id === req.userId);
    const owner = global.users.find(u => u.id === fundraiser.ownerId);

    if (donor) {
        emailService.sendDonationConfirmation(donor.email, donor.name, amount, fundraiser.title);
    }
    if (owner) {
        emailService.sendNewDonationNotification(owner.email, owner.name, amount, fundraiser.title);
    }

    res.status(201).json(newDonation);
});

// Get all donations for a fundraiser
router.get('/:fundraiserId', (req, res) => {
    const fundraiserId = parseInt(req.params.fundraiserId);
    const fundraiserDonations = global.donations
        .filter(d => d.fundraiserId === fundraiserId)
        .map(d => {
            const donor = d.donorId ? global.users.find(u => u.id === d.donorId) : null;
            return {
                amount: d.amount,
                message: d.message,
                donorName: donor ? donor.name : 'Anonymous',
                createdAt: d.createdAt
            };
        });
    res.json(fundraiserDonations);
});

module.exports = router;
