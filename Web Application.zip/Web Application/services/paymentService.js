// Mock Payment Service
// In a real application, this would integrate with a payment gateway like Stripe or PayPal.

const processPayment = (userId, amount) => {
    // For simplicity, we'll just log the payment and assume it's always successful.
    console.log(`Processing payment of ${amount} for user ${userId}...`);
    console.log('Payment successful.');
    return true;
};

module.exports = {
    processPayment
};
