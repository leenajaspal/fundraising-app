// Mock Email Service
// In a real application, this would integrate with an email service like SendGrid or Mailgun.

const sendDonationConfirmation = (donorEmail, donorName, amount, fundraiserTitle) => {
    console.log(`--- Sending Email to ${donorEmail} ---`);
    console.log(`Subject: Thank you for your donation!`);
    console.log(`Hi ${donorName},`);
    console.log(`Thank you for your generous donation of ${amount} to the fundraiser "${fundraiserTitle}".`);
    console.log(`------------------------------------`);
};

const sendNewDonationNotification = (ownerEmail, ownerName, amount, fundraiserTitle) => {
    console.log(`--- Sending Email to ${ownerEmail} ---`);
    console.log(`Subject: You've received a new donation!`);
    console.log(`Hi ${ownerName},`);
    console.log(`Your fundraiser "${fundraiserTitle}" has received a new donation of ${amount}.`);
    console.log(`------------------------------------`);
};

module.exports = {
    sendDonationConfirmation,
    sendNewDonationNotification
};
