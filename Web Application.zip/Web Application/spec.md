# Online Charity Fundraising Application – Implementation Spec

## Overview

Build a web application that matches the following problem description, actors, and use cases. 
The implementation should be simple but clean, suitable for a university coursework project.

## Problem description

The client requires an online charity fundraising application that enables users to create fundraising campaigns and donate securely to registered charities through a digital platform. The system must support key features such as user profile creation, fundraiser management, and secure donation processing.

User Profiles
Guests may browse active fundraising campaigns without creating an account. To participate fully, guest users must register and authenticate, creating a profile that stores their name, email, password, and an optional short biography. Once logged in, users become authenticated and they may update their profile, create new fundraisers, edit or close existing fundraisers, submit reports on inappropriate campaigns, and make donations.

Fundraiser Management
Authenticated users can create fundraising campaigns by providing a title, selecting a charity from the system’s charity catalogue, and specifying a fundraising goal. After creation, users may optionally add a description or story to personalise the campaign. The system should track the amount raised and displays progress towards the goal. The fundraiser owner may edit campaign details or close the campaign manually when the fundraiser is complete. Each campaign is linked by exactly one charity. Authenticated users may report fundraisers they believe to be inappropriate or suspicious. Submitted reports are stored in the system and become visible to administrators for review.

Charity Catalogue
The system maintains an internal catalogue of verified charities. During fundraiser creation, the authenticated user selects a charity from this list. An administrator manages the charity catalogue by adding, editing, or removing charity entries to ensure accuracy and compliance.

Donations and Payments
Authenticated users can donate to any active fundraiser. A donation includes an amount and an optional support message. Authenticated users can donate anonymously, in which case only the donation amount and message (if provided) are shown. The system validates the donation data before initiating payment, which is handled through the Payment Service. On successful payment, a new donation record is created, linked to both the fundraiser and donor, and the fundraiser’s progress is recalculated. The system must display recent donations, messages, and public donor profiles (unless anonymous) on each campaign page.

Email Notifications
Following a successful donation, the donor receives an email confirming the donation and summarising their contribution. The fundraiser owner also receives an email notifying them of the new donation. The notifications are sent via the Email Service and ensure transparency and acknowledgment for all parties involved.

Administrative Functions
Administrators oversee the platform to ensure integrity and compliance. They are responsible for maintaining the charity list, reviewing reported campaigns, and removing fundraisers that violate guidelines, to maintain a safe and trustworthy environment. Administrators cannot create, browse, or donate to fundraisers.


## Actors

- Guest User – can browse active fundraisers and view campaign pages without logging in.
- Authenticated User – can do everything a Guest User can, and additionally register/login, manage their profile, create/edit/close fundraisers, donate to campaigns, and report inappropriate fundraisers.
- Administrator – manages the charity catalogue and moderates reported fundraisers.
- Payment Service – external-like service used to simulate payment processing (no real money).
- Email Service – external-like service used to simulate sending confirmation emails.

## Use cases to implement

### User account & profile
- Register Account
- Login
- Logout
- Manage Profile

### Fundraisers
- Create Fundraiser
- Edit Fundraiser
- Close Fundraiser
- Browse Fundraisers
- View Fundraiser Details

### Donations
- Make Donation (with amount, optional message, anonymous flag)
- Show donations and messages on the fundraiser page

### Reporting & moderation
- Report Fundraiser
- Review Reported Fundraisers
- Remove Fundraiser

### Charity Catalogue
- Manage Charity Catalogue: Add, Edit, Remove Charity
- Users must select a charity from this catalogue when creating a fundraiser.

### System services (simulated)
- Process Payment via a Payment Service (no real payment integration).
- Send Email Notification via an Email Service to:
  - Donor when a donation is made
  - Fundraiser owner when their campaign receives a donation

## Implementation constraints

- Use Node.js + Express for the backend.
- Use a very simple frontend: static HTML/CSS + vanilla JavaScript.
- Store data in memory or JSON files (no real database).
- Suggested file structure:
  - `server.js` – main Express server
  - `routes/auth.js` – register/login/logout
  - `routes/fundraisers.js` – create/edit/close/browse/view fundraisers
  - `routes/donations.js` – make donation and list donations for a fundraiser
  - `routes/admin.js` – manage charities and review/remove reported fundraisers
  - `services/paymentService.js` – fake payment processing
  - `services/emailService.js` – fake email sending (console logs or messages)
  - `public/index.html`, `public/styles.css`, `public/app.js` – frontend
- The code must be consistent with the entities implied by my UML diagrams:
  - User, AuthenticatedUser, Fundraiser, Donation, Charity, CharityCatalogue, Report.
- Keep the code simple, readable, and well-commented.
