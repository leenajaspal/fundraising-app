document.addEventListener('DOMContentLoaded', () => {
    // Main views
    const loggedInView = document.getElementById('logged-in-view');
    const fundraisersList = document.getElementById('fundraisers-list');
    const fundraiserDetailsView = document.getElementById('fundraiser-details');
    const fundraisersView = document.getElementById('fundraisers-view');

    // Modals
    const loginModal = document.getElementById('login-modal');
    const registerModal = document.getElementById('register-modal');
    const createFundraiserModal = document.getElementById('create-fundraiser-modal');
    
    // Auth controls container in the header
    const authControls = document.getElementById('auth-controls');

    // Donation Form
    const donationForm = document.getElementById('donation-form');
    // Report Fundraiser Button
    const reportFundraiserButton = document.getElementById('report-fundraiser');

    let currentSessionId = null;
    let selectedFundraiserId = null;

    // --- API Helper ---
    const api = {
        get: (url) => fetch(`/api${url}`, { headers: { 'X-Session-Id': currentSessionId } }),
        post: (url, data) => fetch(`/api${url}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Session-Id': currentSessionId },
            body: JSON.stringify(data),
        }),
        put: (url, data) => fetch(`/api${url}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'X-Session-Id': currentSessionId },
            body: JSON.stringify(data),
        }),
    };

    // --- Modal Handling ---
    const showModal = (modal) => modal.style.display = 'flex';
    const hideModal = (modal) => modal.style.display = 'none';

    // Close modals when clicking the 'x'
    document.querySelectorAll('.modal-close').forEach(span => {
        span.onclick = () => hideModal(span.closest('.modal'));
    });
    // Close modals when clicking outside the content
    window.onclick = (event) => {
        if (event.target.classList.contains('modal')) {
            hideModal(event.target);
        }
    };

    // --- View Management ---
    const showLoggedOutView = () => {
        loggedInView.style.display = 'none';
        authControls.innerHTML = `
            <button id="login-button" class="button button--outline">Login</button>
            <button id="register-button" class="button button--primary">Register</button>
        `;
        document.getElementById('login-button').onclick = () => showModal(loginModal);
        document.getElementById('register-button').onclick = () => showModal(registerModal);
        donationForm.style.display = 'none'; // Hide donation form for logged out users
        reportFundraiserButton.style.display = 'none'; // Hide report button for logged out users
    };

    const showLoggedInView = (user) => {
        loggedInView.style.display = 'flex';
        authControls.innerHTML = `
            <button id="create-fundraiser-button" class="button button--primary">Create Fundraiser</button>
        `;
        document.getElementById('create-fundraiser-button').onclick = () => showModal(createFundraiserModal);
        document.getElementById('user-name').textContent = user.name;
        document.getElementById('profile-name').value = user.name;
        document.getElementById('profile-bio').value = user.bio;
        donationForm.style.display = 'block'; // Show donation form for logged in users
        reportFundraiserButton.style.display = 'block'; // Show report button for logged in users
    };
    
    const showFundraiserDetails = () => {
        fundraisersView.style.display = 'none';
        fundraiserDetailsView.style.display = 'block';
        // Ensure donation form and report button visibility is correct when viewing details
        if (currentSessionId) {
            donationForm.style.display = 'block';
            reportFundraiserButton.style.display = 'block';
        } else {
            donationForm.style.display = 'none';
            reportFundraiserButton.style.display = 'none';
        }
    };
    
    const showFundraisersListView = () => {
        fundraisersView.style.display = 'block';
        fundraiserDetailsView.style.display = 'none';
    };

    // --- Data Loading ---
    const loadFundraisers = async () => {
        const response = await api.get('/fundraisers');
        const fundraisers = await response.json();
        fundraisersList.innerHTML = '';
        fundraisers.forEach(f => {
            const progress = (f.amountRaised / f.goal) * 100;
            const fundraiserDiv = document.createElement('div');
            fundraiserDiv.className = 'fundraiser';
            fundraiserDiv.innerHTML = `
                <h3>${f.title}</h3>
                <p class="fundraiser-card-charity">For ${f.charityName}</p>
                <div class="progress-bar">
                    <div class="progress-bar__fill" style="width: ${progress}%"></div>
                </div>
                <div class="fundraiser-card-stats">
                    <span class="fundraiser-card-raised">$${f.amountRaised}</span>
                    <span class="fundraiser-card-goal">of $${f.goal}</span>
                </div>
            `;
            fundraiserDiv.onclick = () => loadFundraiserDetails(f.id);
            fundraisersList.appendChild(fundraiserDiv);
        });
    };

    const loadFundraiserDetails = async (id) => {
        selectedFundraiserId = id;
        const response = await api.get(`/fundraisers/${id}`);
        const f = await response.json();

        document.getElementById('details-title').textContent = f.title;
        document.getElementById('details-goal').textContent = f.goal;
        document.getElementById('details-raised').textContent = f.amountRaised;
        document.getElementById('details-description').textContent = f.description;
        document.getElementById('details-owner').textContent = f.ownerName;
        document.getElementById('details-charity').textContent = f.charityName;
        
        loadDonations(id);
        showFundraiserDetails();
    };
    
    const loadDonations = async(fundraiserId) => {
        const response = await api.get(`/donations/${fundraiserId}`);
        const donations = await response.json();
        const donationsListDiv = document.getElementById('donations-list');
        donationsListDiv.innerHTML = '';
        if (donations.length === 0) {
            donationsListDiv.innerHTML = '<p>No donations yet.</p>';
            return;
        }
        donations.forEach(d => {
            const donationDiv = document.createElement('div');
            donationDiv.className = 'donation';
            donationDiv.innerHTML = `<p><b>${d.donorName}</b> donated <b>$${d.amount}</b></p><p>${d.message}</p>`;
            donationsListDiv.appendChild(donationDiv);
        });
    };

    const loadCharities = async () => {
        const response = await api.get('/admin/charities');
        const charities = await response.json();
        const select = document.getElementById('fundraiser-charity');
        select.innerHTML = '';
        charities.forEach(c => {
            const option = document.createElement('option');
            option.value = c.id;
            option.textContent = c.name;
            select.appendChild(option);
        });
    };

    // --- Event Listeners ---
    document.getElementById('register-form').onsubmit = async (e) => {
        e.preventDefault();
        const name = document.getElementById('register-name').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const bio = document.getElementById('register-bio').value;
        await api.post('/auth/register', { name, email, password, bio });
        alert('Registration successful! Please log in.');
        e.target.reset();
        hideModal(registerModal);
        showModal(loginModal);
    };

    document.getElementById('login-form').onsubmit = async (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        const response = await api.post('/auth/login', { email, password });
        if (response.ok) {
            const data = await response.json();
            currentSessionId = data.sessionId;
            const profileResponse = await api.get('/auth/profile');
            const user = await profileResponse.json();
            showLoggedInView(user);
            loadCharities();
            hideModal(loginModal);
        } else {
            alert('Login failed.');
        }
    };
    
    document.getElementById('logout-button').onclick = async () => {
        await api.post('/auth/logout', { sessionId: currentSessionId });
        currentSessionId = null;
        showLoggedOutView();
    };

    document.getElementById('profile-form').onsubmit = async (e) => {
        e.preventDefault();
        const name = document.getElementById('profile-name').value;
        const bio = document.getElementById('profile-bio').value;
        await api.put('/auth/profile', { name, bio });
        alert('Profile updated!');
        const profileResponse = await api.get('/auth/profile');
        const user = await profileResponse.json();
        showLoggedInView(user);
    };

    document.getElementById('create-fundraiser-form').onsubmit = async (e) => {
        e.preventDefault();
        const title = document.getElementById('fundraiser-title').value;
        const charityId = parseInt(document.getElementById('fundraiser-charity').value);
        const goal = parseInt(document.getElementById('fundraiser-goal').value);
        const description = document.getElementById('fundraiser-description').value;
        await api.post('/fundraisers', { title, charityId, goal, description });
        alert('Fundraiser created!');
        e.target.reset();
        hideModal(createFundraiserModal);
        loadFundraisers();
    };
    
    document.getElementById('donation-form').onsubmit = async(e) => {
        e.preventDefault();
        const amount = parseInt(document.getElementById('donation-amount').value);
        const message = document.getElementById('donation-message').value;
        const anonymous = document.getElementById('donation-anonymous').checked;
        await api.post('/donations', { fundraiserId: selectedFundraiserId, amount, message, anonymous });
        alert('Thank you for your donation!');
        e.target.reset();
        loadFundraiserDetails(selectedFundraiserId); // Refresh details
    };
    
    document.getElementById('back-to-fundraisers').onclick = showFundraisersListView;
    
    document.getElementById('report-fundraiser').onclick = async () => {
        await api.post(`/fundraisers/${selectedFundraiserId}/report`);
        alert('Fundraiser reported.');
    };

    // --- Initial Load ---
    showLoggedOutView();
    showFundraisersListView();
    loadFundraisers();
});
