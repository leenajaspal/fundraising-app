const express = require('express');
const app = express();
const port = 3000;

// In-memory data storage
global.users = [
    { id: 1, name: 'Admin User', email: 'admin@example.com', password: 'password', bio: 'I am the admin.' },
    { id: 2, name: 'John Doe', email: 'john@example.com', password: 'password', bio: 'I love to help!' },
    { id: 3, name: 'Jane Smith', email: 'jane@example.com', password: 'password', bio: 'Charity is important.' }
];
global.fundraisers = [
    { id: 1, title: 'Save the Oceans', charityId: 1, goal: 5000, description: 'A campaign to help clean up our oceans and protect marine life.', amountRaised: 2750, ownerId: 2, active: true },
    { id: 2, title: 'Help Build a School', charityId: 2, goal: 10000, description: 'We are raising funds to build a new school in a rural community.', amountRaised: 1500, ownerId: 3, active: true },
    { id: 3, title: 'Support Local Animal Shelter', charityId: 1, goal: 2500, description: 'Our local animal shelter needs support for food and medical supplies.', amountRaised: 2400, ownerId: 2, active: true }
];
global.donations = [
    { id: 1, fundraiserId: 1, donorId: 3, amount: 100, message: 'Great cause!', createdAt: new Date() },
    { id: 2, fundraiserId: 1, donorId: null, amount: 50, message: 'Happy to help.', createdAt: new Date() },
    { id: 3, fundraiserId: 2, donorId: 2, amount: 250, message: 'Lets get this school built!', createdAt: new
Date() },
    { id: 4, fundraiserId: 3, donorId: 3, amount: 500, message: 'For the furry friends!', createdAt: new Date() }
];
global.charities = [
    { id: 1, name: 'Cancer Research' },
    { id: 2, name: 'Teenage Cancer Trust' },
    { id: 3, name: 'Dementia Charity' },
    { id: 4, name: 'Homeless Shelter' }
];
global.reports = [];
global.sessions = {}; // Session management for logged-in users

app.use(express.json());
app.use(express.static('public'));

// Routes
const authRoutes = require('./routes/auth');
const fundraisersRoutes = require('./routes/fundraisers');
const donationsRoutes = require('./routes/donations');
const adminRoutes = require('./routes/admin');

app.use('/api/auth', authRoutes);
app.use('/api/fundraisers', fundraisersRoutes);
app.use('/api/donations', donationsRoutes);
app.use('/api/admin', adminRoutes);

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});
